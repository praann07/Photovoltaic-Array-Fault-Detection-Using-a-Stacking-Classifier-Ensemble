// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Navbar color change on scroll
window.addEventListener('scroll', function() {
    if (window.scrollY > 50) {
        document.querySelector('.navbar').style.backgroundColor = '#1a252f';
    } else {
        document.querySelector('.navbar').style.backgroundColor = '#2c3e50';
    }
});

// Intersection Observer for fade-in animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            
            // Animate importance meters when they become visible
            if (entry.target.classList.contains('range-values-grid')) {
                initImportanceMeters();
            }
        }
    });
}, observerOptions);

// Add fade-in animation to sections
document.querySelectorAll('.section').forEach(section => {
    section.style.opacity = '0';
    section.style.transform = 'translateY(20px)';
    section.style.transition = 'opacity 0.6s ease-out, transform 0.6s ease-out';
    observer.observe(section);
});

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.method-card').forEach((card, index) => {
        card.style.animationDelay = `${index * 0.2}s`;
    });
});

// Add class for animation when section becomes visible
document.addEventListener('scroll', () => {
    document.querySelectorAll('.visible').forEach(element => {
        element.style.opacity = '1';
        element.style.transform = 'translateY(0)';
    });
});

// Function to handle importance meters animation
function initImportanceMeters() {
    document.querySelectorAll('.importance-meter').forEach(meter => {
        const importance = meter.dataset.importance;
        meter.style.setProperty('--importance', `${importance}%`);
    });
}

// Function to enter the main site from landing page
function enterSite() {
    document.querySelector('.landing-page').style.opacity = '0';
    document.querySelector('.landing-page').style.transform = 'scale(1.1)';
    document.querySelector('.landing-page').style.transition = 'all 0.5s ease';
    
    setTimeout(() => {
        document.querySelector('.landing-page').style.display = 'none';
        document.querySelector('.main-content').classList.remove('hidden');
        showSection('introduction');
    }, 500);
}

// Function to toggle mobile navigation
function toggleNav() {
    document.querySelector('.side-nav').classList.toggle('active');
}

// Function to show a specific section
function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.section-content').forEach(section => {
        section.classList.add('hidden');
        section.classList.remove('active');
    });

    // Show and animate the selected section
    const selectedSection = document.getElementById(sectionId);
    if (selectedSection) {
        selectedSection.classList.remove('hidden');
        // Trigger reflow
        void selectedSection.offsetWidth;
        selectedSection.classList.add('active');

        // Initialize importance meters if in dataset section
        if (sectionId === 'dataset') {
            initImportanceMeters();
        }
    }
}

// Event listeners for navigation
document.addEventListener('DOMContentLoaded', () => {
    // Observe all sections and cards for animations
    document.querySelectorAll('.dataset-section, .fault-type-card, .range-card').forEach(element => {
        observer.observe(element);
    });

    // Add click handlers for navigation links
    document.querySelectorAll('.nav-content a').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const section = link.getAttribute('data-section');
            showSection(section);
            
            // Close mobile nav if open
            if (window.innerWidth <= 768) {
                toggleNav();
            }
        });
    });
});

// Handle escape key to close mobile nav
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && window.innerWidth <= 768) {
        document.querySelector('.side-nav').classList.remove('active');
    }
});

document.addEventListener('DOMContentLoaded', function() {
    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    // Intersection Observer for section animations
    const sections = document.querySelectorAll('.section-content');
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px'
    };

    const sectionObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    sections.forEach(section => {
        sectionObserver.observe(section);
    });

    // Show data visualization image
    const img = new Image();
    img.src = 'data_visualization.png';
    img.onload = function() {
        document.getElementById('results-visualization').appendChild(img);
    };

    // Table sorting functionality
    document.querySelectorAll('th').forEach(headerCell => {
        headerCell.addEventListener('click', () => {
            const tableBody = headerCell.closest('table').querySelector('tbody');
            const rows = Array.from(tableBody.querySelectorAll('tr'));
            const index = Array.from(headerCell.parentNode.children).indexOf(headerCell);
            
            const sortedRows = rows.sort((rowA, rowB) => {
                const cellA = rowA.querySelectorAll('td')[index].textContent;
                const cellB = rowB.querySelectorAll('td')[index].textContent;
                return cellA.localeCompare(cellB, undefined, {numeric: true});
            });
            
            tableBody.append(...sortedRows);
        });
    });

    // Dynamic range value visualization
    const rangeCards = document.querySelectorAll('.range-card');
    rangeCards.forEach(card => {
        const importanceMeter = card.querySelector('.importance-meter');
        if (importanceMeter) {
            const importance = card.dataset.importance || '50';
            importanceMeter.style.setProperty('--importance', `${importance}%`);
        }
    });

    // Landing page animations
    const landingContent = document.querySelector('.landing-content');
    if (landingContent) {
        setTimeout(() => {
            landingContent.style.opacity = '1';
            landingContent.style.transform = 'translateY(0)';
        }, 300);
    }

    // Research gap section highlight
    const researchGaps = document.querySelectorAll('.gap-card');
    researchGaps.forEach(gap => {
        gap.addEventListener('mouseenter', () => {
            gap.style.transform = 'translateY(-10px)';
            gap.style.borderColor = 'var(--accent-color)';
        });
        gap.addEventListener('mouseleave', () => {
            gap.style.transform = 'translateY(0)';
            gap.style.borderColor = 'rgba(232, 176, 89, 0.2)';
        });
    });
});

document.addEventListener('DOMContentLoaded', () => {
    // Handle landing page explore button
    const exploreBtn = document.querySelector('.explore-btn');
    const landingPage = document.querySelector('.landing-page');
    const mainContent = document.querySelector('.main-content');

    if (exploreBtn) {
        exploreBtn.addEventListener('click', () => {
            landingPage.style.display = 'none';
            mainContent.classList.remove('hidden');
            // Activate the first section
            const firstSection = document.querySelector('.section-content');
            if (firstSection) {
                firstSection.classList.add('active');
            }
        });
    }

    // Navigation functionality
    const navLinks = document.querySelectorAll('.nav-content a');
    const sections = document.querySelectorAll('.section-content');

    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('data-section');
            
            // Hide all sections and remove active class
            sections.forEach(section => {
                section.classList.add('hidden');
                section.classList.remove('active');
            });

            // Show and activate target section
            const targetSection = document.getElementById(targetId);
            if (targetSection) {
                targetSection.classList.remove('hidden');
                // Add active class after a small delay for animation
                setTimeout(() => {
                    targetSection.classList.add('active');
                }, 50);
            }
        });
    });

    // Mobile navigation toggle
    const navToggle = document.querySelector('.mobile-nav-toggle');
    const sideNav = document.querySelector('.side-nav');

    if (navToggle) {
        navToggle.addEventListener('click', () => {
            sideNav.classList.toggle('active');
        });
    }

    // Intersection Observer for animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, observerOptions);

    // Observe all dataset sections
    document.querySelectorAll('.dataset-section').forEach(section => {
        observer.observe(section);
    });

    // Handle method card interactions
    const methodCards = document.querySelectorAll('.method-card, .ml-card');
    methodCards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'translateY(-10px)';
        });

        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translateY(0)';
        });
    });

    // Initialize range value animations
    const rangeCards = document.querySelectorAll('.range-card');
    rangeCards.forEach(card => {
        const importanceMeter = card.querySelector('.importance-meter');
        if (importanceMeter) {
            const importance = card.getAttribute('data-importance') || '50';
            importanceMeter.style.setProperty('--importance', `${importance}%`);
        }
    });

    // Branch connection lines for mind map
    const branches = document.querySelectorAll('.branch');
    branches.forEach(branch => {
        // Add connection line animation on hover
        branch.addEventListener('mouseenter', () => {
            branch.style.borderColor = getComputedStyle(document.documentElement)
                .getPropertyValue('--accent-color');
        });

        branch.addEventListener('mouseleave', () => {
            branch.style.borderColor = 'rgba(255, 255, 255, 0.1)';
        });
    });

    // Handle visualization interactions
    const vizItems = document.querySelectorAll('.viz-item');
    vizItems.forEach(item => {
        item.addEventListener('click', () => {
            // Remove active class from all items
            vizItems.forEach(vi => vi.classList.remove('active'));
            // Add active class to clicked item
            item.classList.add('active');
        });
    });
});