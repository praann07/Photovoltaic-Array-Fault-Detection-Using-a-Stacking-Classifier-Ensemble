import matplotlib.pyplot as plt
import networkx as nx
from matplotlib.patches import FancyArrowPatch, Rectangle

# Create a directed graph
G = nx.DiGraph()

# Define custom colors
NODE_COLORS = {
    'input_output': '#90EE90',  # Light green
    'process': '#ADD8E6',       # Light blue
    'arrow': '#2E8B57',        # Sea green
    'text': '#2F4F4F'          # Dark slate gray
}

# Define node texts with proper line breaks
node_texts = {
    "Input": "Input:\nSimulated\n250-kW PV\nDataset",
    "Loading": "Data Loading\n&\nValidation",
    "Features": "Feature\nExtraction\n(30 Features)",
    "Standard": "Standardization\n(StandardScaler)",
    "Stacking": "Stacking\nClassifier",
    "Base": "Base\nLearners",
    "Meta": "Meta\nLearner",
    "Training": "Model Training\n(600 Train,\n50 Test)",
    "Evaluation": "Model\nEvaluation",
    "Metrics": "Performance\nMetrics",
    "Visual": "Visualizations",
    "Output": "Output:\nFault Detection\n(93% Accuracy)"
}

# Define positions for a horizontal layout
pos = {
    "Input": (0, 0),
    "Loading": (2, 0),
    "Features": (4, 0),
    "Standard": (6, 0),
    "Stacking": (8, 0),
    "Base": (8, 2),
    "Meta": (8, -2),
    "Training": (10, 0),
    "Evaluation": (12, 0),
    "Metrics": (14, 1),
    "Visual": (14, -1),
    "Output": (16, 0)
}

# Define edges
edges = [
    ("Input", "Loading"),
    ("Loading", "Features"),
    ("Features", "Standard"),
    ("Standard", "Stacking"),
    ("Stacking", "Base"),
    ("Stacking", "Meta"),
    ("Base", "Training"),
    ("Meta", "Training"),
    ("Training", "Evaluation"),
    ("Evaluation", "Metrics"),
    ("Evaluation", "Visual"),
    ("Metrics", "Output"),
    ("Visual", "Output")
]

# Create figure
plt.figure(figsize=(20, 8))
ax = plt.gca()

# Function to draw a node with text inside
def draw_node_with_text(pos, text, color):
    x, y = pos
    width, height = 1.5, 1.0
    
    rect = Rectangle((x - width/2, y - height/2), width, height,
                    facecolor=color,
                    edgecolor='gray',
                    alpha=0.9,
                    linewidth=1,
                    zorder=1)
    ax.add_patch(rect)
    
    ax.text(x, y, text,
            horizontalalignment='center',
            verticalalignment='center',
            fontsize=9,
            fontweight='bold',
            zorder=2)

# Draw nodes with text inside
for node in pos:
    node_color = NODE_COLORS['input_output'] if node in ["Input", "Output"] else NODE_COLORS['process']
    draw_node_with_text(pos[node], node_texts[node], node_color)

# Draw arrows
for edge in edges:
    start = pos[edge[0]]
    end = pos[edge[1]]
    
    dx = end[0] - start[0]
    dy = end[1] - start[1]
    
    # Adjust start and end points
    if dy == 0:  # horizontal arrows
        start = (start[0] + 0.8, start[1])
        end = (end[0] - 0.8, end[1])
    else:  # vertical arrows
        if dx > 0:  # going up or down from main flow
            start = (start[0] + 0.1, start[1])
            end = (end[0] - 0.1, end[1])
        else:  # returning to main flow
            start = (start[0], start[1])
            end = (end[0], end[1])

    arrow = FancyArrowPatch(
        start, end,
        arrowstyle='-|>',
        connectionstyle=f'arc3,rad={0.2 if dy != 0 else 0}',
        color=NODE_COLORS['arrow'],
        linewidth=2,
        mutation_scale=20,
        shrinkA=5,
        shrinkB=5,
        zorder=0
    )
    ax.add_patch(arrow)

# Add annotations
def add_annotation(x, y, text):
    plt.text(x, y, text,
             bbox=dict(facecolor='white',
                      alpha=0.9,
                      edgecolor='gray',
                      boxstyle='round,pad=0.5'),
             fontsize=8,
             color=NODE_COLORS['text'],
             ha='left',
             va='center')

# Add context annotations
add_annotation(0, 2, "Dataset Classes:\nFault-Free (16.67%)\nString (25.5%)\nString-to-Ground (24.83%)\nString-to-String (33%)")
add_annotation(8, 3, "Base Learners:\nAdaBoost (50 est.)\nRandomForest (100 trees)\nGradientBoosting (100 est.)")
add_annotation(8, -3, "Meta-Learner:\nAdaBoost (50 est.)")
add_annotation(14, 2, "Metrics:\nAcc: 93%\nPrec: 93.98%\nRec: 93%\nF1: 92.7%\nAROC: 0.9457")

# Title
plt.title("PV Fault Detection System Pipeline",
          fontsize=16,
          pad=20,
          fontweight='bold',
          color=NODE_COLORS['text'])

# Set proper axis limits
plt.xlim(-2, 18)
plt.ylim(-3, 4)

# Final touches
plt.axis('off')
plt.tight_layout()

# Save high-resolution image
plt.savefig("horizontal_flowchart.png",
            dpi=300,
            bbox_inches='tight',
            pad_inches=0.5,
            facecolor='white',
            edgecolor='none')

plt.show()
