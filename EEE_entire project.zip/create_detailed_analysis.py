import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
import numpy as np
from pathlib import Path

def create_analysis_folder(base_path, folder_name):
    """Create folder if it doesn't exist"""
    folder_path = Path(base_path) / folder_name
    folder_path.mkdir(parents=True, exist_ok=True)
    return folder_path

def generate_dataset_info(df, output_path, file_name):
    """Generate detailed information about the dataset and save visualizations"""
    # Create text file with dataset information
    with open(output_path / f"{file_name}_analysis.txt", "w") as f:
        f.write(f"=== Analysis for {file_name} ===\n\n")
        
        # Basic information
        f.write("1. Basic Information:\n")
        f.write(f"Number of rows: {df.shape[0]}\n")
        f.write(f"Number of columns: {df.shape[1]}\n")
        f.write(f"Columns: {', '.join(df.columns)}\n\n")
        
        # Data types
        f.write("2. Data Types:\n")
        f.write(df.dtypes.to_string())
        f.write("\n\n")
        
        # Statistical summary
        f.write("3. Statistical Summary:\n")
        f.write(df.describe().to_string())
        f.write("\n\n")
        
        # Missing values
        f.write("4. Missing Values:\n")
        missing = df.isnull().sum()
        f.write(missing.to_string())
        f.write("\n\n")
        
        # Unique values per column
        f.write("5. Unique Values Count:\n")
        for col in df.columns:
            f.write(f"{col}: {df[col].nunique()} unique values\n")
        
        # Data sample
        f.write("\n6. First 5 rows of data:\n")
        f.write(df.head().to_string())

    # Generate visualizations
    plt.figure(figsize=(12, 8))
    
    # Histogram for each numerical column
    numerical_cols = df.select_dtypes(include=[np.number]).columns
    for col in numerical_cols:
        plt.figure(figsize=(10, 6))
        plt.hist(df[col], bins=30)
        plt.title(f'Histogram of {col}')
        plt.xlabel(col)
        plt.ylabel('Frequency')
        plt.savefig(output_path / f"{file_name}_{col}_histogram.png")
        plt.close()

    # Correlation matrix
    if len(numerical_cols) > 1:
        plt.figure(figsize=(12, 8))
        correlation_matrix = df[numerical_cols].corr()
        sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt='.2f')
        plt.title(f'Correlation Matrix - {file_name}')
        plt.tight_layout()
        plt.savefig(output_path / f"{file_name}_correlation_matrix.png")
        plt.close()

def main():
    # Base paths
    base_path = Path("C:/Users/mspb2/Downloads/archive/visualization")
    
    # List of files to analyze
    files_to_analyze = [
        "organized_test_data",
        "organized_train_data",
        "train_current_measurements",
        "train_current_statistics",
        "train_power_and_other",
        "train_ranges",
        "train_target",
        "train_total_current",
        "train_voltage_dc"
    ]

    # Process each file
    for file_name in files_to_analyze:
        try:
            # Create folder for this file
            output_folder = create_analysis_folder(base_path, file_name)
            
            # Read the CSV file from organized_data folder
            df = pd.read_csv(f"organized_data/{file_name}.csv")
            
            # Copy the original CSV to the new folder
            df.to_csv(output_folder / f"{file_name}.csv", index=False)
            
            # Generate analysis and visualizations
            generate_dataset_info(df, output_folder, file_name)
            
            print(f"Completed analysis for {file_name}")
            
        except Exception as e:
            print(f"Error processing {file_name}: {e}")

    print("\nAnalysis complete! Check the visualization folder for results.")

if __name__ == "__main__":
    main()
