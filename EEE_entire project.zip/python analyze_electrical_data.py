import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def load_and_analyze_data():
    # Read the CSV files
    try:
        train_data = pd.read_csv("C:/Users/mspb2/Downloads/archive/train data.csv", sep=';')
        test_data = pd.read_csv("C:/Users/mspb2/Downloads/archive/test data.csv", sep=';')
        
        print("Data loaded successfully!")
    except Exception as e:
        print(f"Error loading data: {e}")
        return

    # Create output directory for organized data and visualizations
    import os
    if not os.path.exists('organized_data'):
        os.makedirs('organized_data')

    # Group related columns for better organization
    column_groups = {
        'Current_Measurements': ['I1', 'I2', 'I3', 'I4', 'I5', 'I6'],
        'Current_Statistics': ['I1MAX', 'I1MIN', 'I1VAR', 'I2MAX', 'I2MIN', 'I2VAR',
                             'I3max', 'I3min', 'I3var', 'I4MAX', 'I4MIN'],
        'Total_Current': ['Itotal1', 'Itotalmax1', 'Itotalmin1'],
        'Voltage_DC': ['Vdcmean1', 'Vdcmax1', 'Vdcmin1'],
        'Power_and_Other': ['Pdcmean1', 'IR', 'T'],
        'Ranges': ['range 1', 'range 2', 'range 3', 'range 4'],
        'Target': ['class']
    }

    # Basic dataset information
    print("\n=== Dataset Information ===")
    print("\nTraining Data Shape:", train_data.shape)
    print("Test Data Shape:", test_data.shape)

    # Display basic statistics for training data
    print("\n=== Training Data Statistics ===")
    print(train_data.describe())

    # Check for missing values
    print("\n=== Missing Values in Training Data ===")
    missing_values = train_data.isnull().sum()
    print(missing_values[missing_values > 0] if missing_values.any() > 0 else "No missing values found")

    # Create visualizations
    plt.figure(figsize=(15, 10))

    # Distribution of current measurements
    plt.subplot(2, 2, 1)
    for current in ['I1', 'I2', 'I3', 'I4', 'I5', 'I6']:
        sns.kdeplot(data=train_data, x=current, label=current)
    plt.title('Distribution of Current Measurements')
    plt.legend()

    # Voltage distributions
    plt.subplot(2, 2, 2)
    for voltage in ['Vdcmean1', 'Vdcmax1', 'Vdcmin1']:
        sns.kdeplot(data=train_data, x=voltage, label=voltage)
    plt.title('Distribution of Voltage Measurements')
    plt.legend()

    # Class distribution
    plt.subplot(2, 2, 3)
    train_data['class'].value_counts().plot(kind='bar')
    plt.title('Distribution of Classes')
    plt.xlabel('Class')
    plt.ylabel('Count')

    # Power vs IR scatter plot
    plt.subplot(2, 2, 4)
    plt.scatter(train_data['Pdcmean1'], train_data['IR'], alpha=0.5)
    plt.title('Power vs IR')
    plt.xlabel('Power (Pdcmean1)')
    plt.ylabel('IR')

    plt.tight_layout()
    plt.savefig('organized_data/data_visualization.png')
    print("\nVisualizations saved as 'data_visualization.png'")

    # Save organized datasets
    # Training data organized by groups
    for group_name, columns in column_groups.items():
        group_data = train_data[columns]
        group_data.to_csv(f'organized_data/train_{group_name.lower()}.csv', index=False)
        
        # Display first few rows of each group
        print(f"\n=== {group_name} (First 5 rows) ===")
        print(group_data.head())

    # Save complete organized datasets
    train_data.to_csv('organized_data/organized_train_data.csv', index=False)
    test_data.to_csv('organized_data/organized_test_data.csv', index=False)
    
    print("\n=== Data Organization Complete ===")
    print("Organized files have been saved in the 'organized_data' folder")
    print("\nFiles created:")
    print("1. organized_train_data.csv - Complete training dataset")
    print("2. organized_test_data.csv - Complete test dataset")
    print("3. Separate CSV files for each column group")
    print("4. data_visualization.png - Visual analysis of the data")

if __name__ == "__main__":
    load_and_analyze_data()
